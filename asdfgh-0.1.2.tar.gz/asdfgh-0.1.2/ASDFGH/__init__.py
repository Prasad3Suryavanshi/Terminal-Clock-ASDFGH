# asdfgh/__init__.py
from .clock import ColorClock, Theme, quick_start

__version__ = "0.1.1"
__all__ = ["ColorClock", "Theme", "quick_start"]